# cypress-api-testing
API tests, using Cypress for Swagger Petstore Sample

# How to run the tests
## Prerequisites
You need to run the Swagger Petstore Sample locally. Follow the instructions of this [README.md](https://github.com/swagger-api/swagger-petstore) file.

## Running the tests
1. Clone the repository
2. run `npm install` to install all dependencies
3. run `npm run test` to run the tests
